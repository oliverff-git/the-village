CI-E2E Result

- Summary: Ensured Playwright smoke runs in CI with Docker Compose bringing up postgres, redis, minio, api, and web.
- Tests: apps/web/tests-e2e/smoke.spec.ts verifies redirect from "/" to "/feed" using baseURL http://localhost:3000.
- Compose: docker-compose.yml defines postgres, redis, minio (with healthcheck), api (uvicorn), worker, and web (Next.js) with proper dependencies.
- API Dockerfile: apt-get sequence uses update, install with --no-install-recommends, and cleans apt lists; suitable for slim image builds.
- CI Workflow: Added explicit web build step before Playwright install and compose up to align with runbook commands.
- Commands used in CI e2e job: pnpm --filter web build; npx playwright install --with-deps; docker compose up -d postgres redis minio api web; pnpm --filter web test:e2e.

Acceptance: e2e job should pass after services are healthy and web is built.
