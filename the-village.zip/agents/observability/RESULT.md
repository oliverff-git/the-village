Observability Result

- Summary: API exposes JSON logs with request IDs, /health, and Prometheus metrics; added RUNBOOK notes.
- API: apps/api/main.py adds RequestIdMiddleware, configures structlog JSON, and exposes `/health` and `/metrics` (via Instrumentator).
- Runbook: docs/OPERATIONS.md covers startup, health check, metrics, and basic ops.
- Smoke: curl -s localhost:8000/health returns 200 with {"status":"healthy"}.

Acceptance: /health returns 200; logs include request id.
