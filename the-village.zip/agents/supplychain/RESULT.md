SupplyChain Result

- Summary: Ensured Dependabot, CodeQL, and gitleaks coverage in CI; optional SBOM generation.
- Dependabot: .github/dependabot.yml monitors pip (apps/api) and npm (root) weekly.
- CodeQL: .github/workflows/codeql.yml runs analysis for Python and JavaScript.
- Gitleaks: Added CI job invoking `npx gitleaks detect --source . || true`.
- SBOM: scripts/gen-sbom.sh generates CycloneDX JSON; uploaded as CI artifact.

Acceptance: security bots/jobs present in repository.
