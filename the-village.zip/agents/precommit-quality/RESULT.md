Precommit-Quality Result

- Summary: Configured Python formatting and linting locally and in CI.
- Pre-commit: .pre-commit-config.yaml includes Black (24.8.0) and Ruff (v0.6.9) scoped to apps/api.
- Makefile: format target runs pnpm format (web) and black for apps/api; lint target runs pnpm lint (web) and ruff for apps/api; optional mypy target present.
- CI: api-python job runs ruff and black --check, matching acceptance criteria.
- Usage: make format lint

Acceptance: format/lint jobs run green in CI.
