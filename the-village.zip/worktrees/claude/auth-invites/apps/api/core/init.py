
Core module
