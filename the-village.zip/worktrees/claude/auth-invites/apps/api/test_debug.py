#!/usr/bin/env python3
import sys
import os
sys.path.append(os.getcwd())

from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

print("Testing registration...")
response = client.post(
    "/auth/register",
    json={"email": "u1@example.com", "handle": "u1", "password": "password123", "age_confirmed": True},
)
print(f"Register status: {response.status_code}")
if response.status_code != 200:
    print(f"Register error: {response.text}")

print("Testing login...")
response = client.post("/auth/login", json={"email": "u1@example.com", "password": "password123"})
print(f"Login status: {response.status_code}")
if response.status_code != 200:
    print(f"Login error: {response.text}")
else:
    token = response.json().get("access_token")
    print(f"Got token: {bool(token)}")

print("Testing invite creation...")
response = client.post("/invites/", headers={"Authorization": f"Bearer {token}"})
print(f"Invite create status: {response.status_code}")
if response.status_code != 200:
    print(f"Invite create error: {response.text}")
else:
    invite_token = response.json().get("token")
    print(f"Got invite token: {bool(invite_token)}")

    print("Testing invite validation...")
    response = client.post(f"/invites/join/{invite_token}")
    print(f"Invite validate status: {response.status_code}")
    if response.status_code != 200:
        print(f"Invite validate error: {response.text}")
    else:
        print(f"Validation result: {response.json()}")